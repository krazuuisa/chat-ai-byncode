# AI Proxy Server for ChatGPT
Backend Express server untuk proxy permintaan ke OpenAI GPT API tanpa mengekspos API key di frontend.
